import asyncio, time
from datetime import datetime
import copra.rest
from copra.websocket import Channel, Client
import pandas as pd
import LOB_funcs as LOBf
import history_funcs as hf 
import gc

pd.set_option('display.max_columns', 500)

class L2_Update(Client):
    def __init__(self, loop, channel, input_args):
        self.time_now = datetime.utcnow() #initial start time
        self.hist = LOBf.history()
        self.position_range = input_args.position_range
        self.recording_duration = input_args.recording_duration
        self.snap_received = False
        super().__init__(loop, channel) # something about a parent class sending attributes to the child class (Ticker)

    def on_open(self):
        print("Let's count the L2 messages!", self.time_now)
        super().on_open() # inheriting things from the parent class who really knows    

    def on_message(self, msg):
        """ PERFORMING OPERATIONS ON self.x"""
        if msg['type'] in ['snapshot']:
            time = self.time_now
            self.hist.initialize_snap_events(msg,self.time_now)
            self.snap_received = True

        if msg['type'] in ['ticker']:
            if self.snap_received:
                time=datetime.strptime(msg['time'],'%Y-%m-%dT%H:%M:%S.%fZ') # msg['time'] into a datetime object
                best_bid, best_ask = float(msg['best_bid']) , float(msg['best_ask'])
                side = msg['side']
                spread = best_ask - best_bid
                mid_price = 0.5*(best_bid + best_ask)
                message = [time, 'market', float(msg['price']), float(msg['last_size']), 0, mid_price, spread]
                if side == 'buy':
                    self.hist.ask_events = self.hist.add_market_order_message(message, self.hist.ask_events)
                    self.hist.check_mkt_can_overlap(self.hist.ask_events, 'market')
                elif side == 'sell':
                    self.hist.bid_events = self.hist.add_market_order_message(message, self.hist.bid_events)
                    self.hist.check_mkt_can_overlap(self.hist.bid_events, 'market')
                else:
                    print("unknown matched order")
            else:
                print("mkt order arrived but no snapshot received yet")

        if msg['type'] in ['l2update']:# update messages 
            time=datetime.strptime(msg['time'],'%Y-%m-%dT%H:%M:%S.%fZ') #from the message extract time
            changes = msg['changes'] #from the message extract the changes
            side = changes[0][0] #side in which the changes happend (don't worry its orderbook crap)
            price_level = float(changes[0][1]) #the position in x_range that the change is affecting
            level_depth = float(changes[0][2]) #the value in x_volm that is changing
            pre_level_depth = 0 
            self.hist.token = False
            if side == "buy":
                price_match_index = list(filter(lambda x: LOBf.price_match(self.hist.bid_range[x], price_level), range(len(self.hist.bid_range))))
                LOBf.UpdateSnapshot_bid_Seq(self.hist, time, side, price_level, level_depth, pre_level_depth, price_match_index)
            elif side == "sell":
                price_match_index = list(filter(lambda x: LOBf.price_match(self.hist.ask_range[x], price_level), range(len(self.hist.ask_range))))
                LOBf.UpdateSnapshot_ask_Seq(self.hist, time, side, price_level, level_depth, pre_level_depth, price_match_index)                
            else:
                print("unknown message")

        if (datetime.utcnow() - self.time_now).total_seconds() > self.recording_duration:  # after 1 second has passed
            self.loop.create_task(self.close()) # ASyncIO nonsense

    def on_close(self, was_clean, code, reason):
        print("Connection to server is closed")
        print(was_clean)
        print(code)
        print(reason)
        """Massages my list of [time, [[price, volm], ... , [price,volm]]] into a clean dataframe""" 
        final_bid_list, final_bid_prices = hf.convert_array_to_list_dict(self.hist.bid_history, self.position_range)
        final_ask_list, final_ask_prices = hf.convert_array_to_list_dict(self.hist.ask_history, self.position_range)
        final_signed_list, final_signed_prices = hf.convert_array_to_list_dict_sob(self.hist.signed_history, self.hist.signed_events)

        title1 = "L2_orderbook_volm_bid"+str(self.hist.bid_events[-1][0])+".xlsx"
        hf.pd_excel_save(title1, final_bid_list)

        title2 = "L2_orderbook_volm_ask"+str(self.hist.ask_events[-1][0])+".xlsx"
        hf.pd_excel_save(title2, final_ask_list)

        title3 = "L2_orderbook_events_bid" +str(self.hist.bid_events[-1][0])+".xlsx"
        hf.pd_excel_save(title3, self.hist.bid_events)

        title4 = "L2_orderbook_events_ask" +str(self.hist.ask_events[-1][0])+".xlsx"        
        hf.pd_excel_save(title4, self.hist.ask_events)

        title5 = "L2_orderbook_prices_bid"+str(self.hist.bid_events[-1][0])+".xlsx"
        hf.pd_excel_save(title5, final_bid_prices)

        title6 = "L2_orderbook_prices_ask"+str(self.hist.ask_events[-1][0])+".xlsx"
        hf.pd_excel_save(title6, final_ask_prices)

        title7 = "L2_orderbook_volm_signed"+str(self.hist.signed_events[-1][0])+".xlsx"
        hf.pd_excel_save(title7, final_signed_list)

        title8 = "L2_orderbook_events_signed" +str(self.hist.signed_events[-1][0])+".xlsx"
        hf.pd_excel_save(title8, self.hist.signed_events)

        title8 = "L2_orderbook_prices_signed"+str(self.hist.signed_events[-1][0])+".xlsx"
        hf.pd_excel_save(title8, final_signed_prices)

        gc.collect()

def main():
    pass

if __name__ == '__main__':
    main()