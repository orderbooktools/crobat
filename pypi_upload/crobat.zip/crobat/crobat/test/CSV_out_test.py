import recorder_full as rec
import asyncio, time
from datetime import datetime
import copra.rest
from copra.websocket import Channel, Client

class input_args(object):
    def __init__(self, currency_pair='ETH-USD', position_range=5, recording_duration=10):
        self.currency_pair = currency_pair
        self.position_range = position_range
        self.recording_duration = recording_duration

def main():
    settings = input_args(recording_duration=2)
    loop = asyncio.get_event_loop()
    channel = Channel('level2', settings.currency_pair) 
    channel2 =Channel('ticker', settings.currency_pair)
    ws = rec.L2_Update(loop, channel, settings)
    ws.subscribe(channel2)
    count = 0
    timestart=datetime.utcnow()

    try:     
       loop.run_forever()


    except KeyboardInterrupt:
        loop.run_until_complete(ws.close())
        loop.close()

if __name__ == '__main__':
    main()